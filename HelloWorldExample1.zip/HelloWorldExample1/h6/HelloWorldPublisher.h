// Copyright 2016 Proyectos y Sistemas de Mantenimiento SL (eProsima).
//ss
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @file HelloWorldPublisher.h
 *
 */

#ifndef HELLOWORLDPUBLISHER_H_
#define HELLOWORLDPUBLISHER_H_

#include "OpenCVBufferType.h"

#include <fastrtps/fastrtps_fwd.h>
#include <fastrtps/attributes/PublisherAttributes.h>
#include <fastrtps/publisher/PublisherListener.h>

#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/videoio.hpp>
using namespace eprosima::fastrtps;

class HelloWorldPublisher {
public:
	HelloWorldPublisher();
	virtual ~HelloWorldPublisher();
	cv::VideoCapture m_cap;
	//!Initialize
	bool init();
	//!Publish a sample
	bool publish();
	//!Run for number samples
	void run(uint32_t number);
    std::string encoding;
    std::vector<uchar> buf;
    int len;
private:
	eprosima::fastrtps::Participant* mp_participant;
	eprosima::fastrtps::Publisher* mp_publisher;
	// class PubListener:public PublisherListener
	// {
	// public:
	// 	PubListener():n_matched(0){};
	// 	~PubListener(){};
	// 	void onPublicationMatched(Publisher* pub,MatchingInfo& info);
	// 	int n_matched;
	// }m_listener;
	class PubListener:public eprosima::fastrtps::PublisherListener
	{
	public:
		PubListener():n_matched(0){};
		~PubListener(){};
		void onPublicationMatched(eprosima::fastrtps::Publisher* pub, eprosima::fastrtps::rtps::MatchingInfo& info);
		int n_matched;
	}m_listener;
	OpenCVBufferType m_type;
};



#endif /* HELLOWORLDPUBLISHER_H_ */
